import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import GetAuteur from "./components/GetAuteur";

import Home from "./Pages/home";
import ThankYou from "./Pages/thankYou";
import Authors from "./Pages/authors";
import Books from "./Pages/books";
import SignUp from "./Pages/signUp";
import Login from "./Pages/login";
import Cart from "./Pages/cart";
import History from "./Pages/history";
import BookDetails from "./components/BooksDetails";
import AuthorsDetails from "./components/AuthorsDetails";
import '../src/App.css'


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/authors" element={<Authors />} />
        <Route path="/books" element={<Books />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/login" element={<Login />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/history" element={<History />} />
        <Route path="/thank-you" element={<ThankYou />} />
        <Route path="/books/:id" element={<BookDetails />} />
        <Route path="/authors/:id" element={<AuthorsDetails />} />

        <Route path="/" element={<GetAuteur/>}/>

      </Routes>
    </Router>
  );
}

export default App;



