// ThankYouPage.jsx
import { Link } from "react-router-dom";

function ThankYouPage() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Merci pour votre achat !</h1>
      <p>Nous espérons que vous apprécierez vos livres.</p>
      <Link to="/">
        <button style={{ marginTop: "20px", padding: "10px 20px" }}>Retour à la bibliothèque</button>
      </Link>
    </div>
  );
}

export default ThankYouPage;
