import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";

import Navbar from "./Navbar";

function BookDetails(){
  const [book, setBook ] = useState({});
  const [message, setMessage] = useState("");
  const routeParams = useParams();
  const navigate = useNavigate();

console.log(`http://localhost:4000/api/books/${routeParams.id}`);

  useEffect(() => {
    fetch(`http://localhost:4000/api/books/${routeParams.id}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },

      credentials: 'include',
    })
      .then((response) => response.json())
      .then(data => {
        console.log(data);
        setBook(data.details)
      })
      .catch((error) => console.log(error));
  }, []);
  
  console.log("BOOK", book);

  


  
  const addToCart = async () => {
    try {
      const response = await fetch("http://localhost:4000/api/purchase/cart", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ bookID: book.ID, quantity: 1 }), 
        credentials: "include",
      });

      if (response.ok) {
        setMessage("Livre ajouté au panier avec succès !");
      } else {
        const errorData = await response.json();
        setMessage(errorData.error || "Erreur lors de l'ajout au panier.");
      }
    } catch (err) {
      console.error(err);
      setMessage("Une erreur s'est produite.");
    }
  };
  

  return (
    <div>
      <Navbar />
      <h1>Détails du Livre</h1>
      <p><strong>ID :</strong> {book.ID}</p>
      <p><strong>Title :</strong> {book.Title}</p>
      <p><strong>Description :</strong> {book.Summary}</p>
      <p><strong>Prix :</strong> {book.Price}</p>
      <p><strong>Auteur :</strong> {book.Author}</p>

      <button onClick={addToCart}>ajouter au panier</button>
      <button onClick={() => navigate(-1)}>Retour</button>
      {message && <p>{message}</p>}

    </div>
  );
}

export default BookDetails;











// const fetchData = async () => {
  //   console.log("fetch les articles");
  //   try {
  //     const response = await fetch(`http://localhost:4000/api/purchase/cart`,{
  //       method: 'POST',
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //       body: JSON.stringify(id, quantity),
  //       credentials: 'include',
  //     });


  //   }catch (err) {
  //     console.log("Une erreur s'est produite :", err);
  //   }   
    
  // };