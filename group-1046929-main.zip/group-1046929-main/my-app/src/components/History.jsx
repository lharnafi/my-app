// import { useEffect, useState } from "react";

// function PurchaseHistory() {
//   const [history, setHistory] = useState([]);
//   const [books, setBooks] = useState({}); // Stocker les détails des livres par ID
  

//   // Fonction pour récupérer l'historique
//   const fetchHistory = async () => {
//     try {
//       const response = await fetch("http://localhost:4000/api/purchase-history/{userID}", {
//         method: "GET",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         credentials: "include",
//       });

//       if (response.ok) {
//         const data = await response.json();
//         setHistory(data); // Enregistrer l'historique brut
//         fetchBookDetails(data); // Récupérer les détails des livres
//       } else {
//         console.error("Erreur lors de la récupération de l'historique :", response.status);
//       }
//     } catch (err) {
//       console.error("Erreur réseau :", err);
//     }
//   };

//   // Fonction pour récupérer les détails des livres
//   const fetchBookDetails = async (history) => {
//     const bookIDs = [...new Set(history.map((item) => item.Book))]; // Extraire les IDs uniques
//     const bookDetails = {};

//     for (const bookID of bookIDs) {
//       try {
//         const response = await fetch(`http://localhost:4000/api/books/${bookID}`, {
//           method: "GET",
//           headers: {
//             "Content-Type": "application/json",
//           },
//         });

//         if (response.ok) {
//           const book = await response.json();
//           bookDetails[bookID] = book; // Associer l'ID au détail
//         }
//       } catch (err) {
//         console.error(`Erreur lors de la récupération du livre ${bookID} :`, err);
//       }
//     }

//     setBooks(bookDetails); // Mettre à jour l'état des livres
//   };

//   // Charger l'historique au montage
//   useEffect(() => {
//     fetchHistory();
//   }, []);

//   return (
//     <div>
//       <h1>Historique d'Achats</h1>
//       <table>
//         <thead>
//           <tr>
//             <th>Titre</th>
//             <th>Quantité</th>
//             <th>Prix Total</th>
//             <th>Date d'Achat</th>
//           </tr>
//         </thead>
//         <tbody>
//           {history.map((item, index) => (
//             <tr key={index}>
//               <td>{books[item.BookId]?.title || "Chargement..."}</td>
//               <td>{item.Quantity}</td>
//               <td>{item.Total_price}€</td>
//               <td>{item.Payment_timestamp}</td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// }

// export default PurchaseHistory;
