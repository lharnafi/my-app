 import { useState } from "react";
 import { Link } from "react-router-dom";

function GetAuteur(){
  const [data, setData] = useState([]);

  const fetchData = async () => {
    console.log("Fetch la liste des auteurs");
    try {
      const response = await fetch("http://localhost:4000/api/authors", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: 'include',
      });
  
      if (response.ok) {
        const data = await response.json();
        setData(data || []); 
        console.log("Réponse reçue:", data.details); 
        
        
        
      } else {
        console.error("Erreur lors du fetch des auteurs", response.status);
      }
    } catch (err) {
      console.log("Une erreur s'est produite :", err);
    }
  };
  
  return (
    <div>
      <h1>Library</h1>
      <div>
        <h2>Liste des données</h2>
        <ul>
          {Array.isArray(data.details) && data.details.map((item) => (
            <li key={item.ID}>
              {item.ID} {item.Name} {item.Birth_Date} {item.Description}
              <Link to={`/authors/${item.ID}`}>
                  <button>Afficher l'Auteur</button>
                </Link>
            </li>
          ))}
        </ul>
        <button onClick={fetchData}>Afficher les auteurs</button>
        
        
      </div>
    </div>
  );
}

export default GetAuteur;
