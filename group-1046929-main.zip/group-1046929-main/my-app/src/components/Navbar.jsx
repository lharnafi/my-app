import React from "react";
import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav className="navbar">
      <Link className="navbar-link" to="/" style={{ margin: "0 10px" }}>Home</Link>
      <Link className="navbar-link" to="/authors" style={{ margin: "0 10px" }}>Authors</Link>
      <Link className="navbar-link" to="/books" style={{ margin: "0 10px" }}>Books</Link>
      <Link className="navbar-link" to="/signup" style={{ margin: "0 10px" }}>SignUp</Link>
      <Link className="navbar-link" to="/login" style={{ margin: "0 10px" }}>Login</Link>
      <Link className="navbar-link" to="/cart" style={{ margin: "0 10px" }}>Cart</Link>
      {/* <Link to="/history" style={{ margin: "0 10px" }}>History</Link> */}
    </nav>
  );
}
