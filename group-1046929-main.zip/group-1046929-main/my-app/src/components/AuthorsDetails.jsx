import { useState, useEffect } from "react";
import { useParams, useNavigate, data } from "react-router-dom";
import Navbar from "./Navbar";

function AuthorsDetails() {
  const [author, setAuthor] = useState(null); // Initialiser avec null pour gérer l'état de chargement
  const routeParams = useParams(); // Récupérer l'ID depuis les paramètres de route
  const navigate = useNavigate(); // Permet de naviguer dans l'application

  useEffect(() => {
    // Fetch les détails de l'auteur
    fetch(`http://localhost:4000/api/authors/${routeParams.id}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
      credentials: "include", // Si des cookies ou des tokens sont nécessaires
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
      })
      .then((data) => {
        console.log("Données de l'auteur reçues :", data);
        setAuthor(data.details); // Accédez directement à `data.details`
      })
      .catch((data))

      .catch((error) => {
        console.error("Erreur lors de la récupération des données :", error);
      });
  }, [routeParams.id]); // Ajoutez `routeParams.id` comme dépendance

  if (!author) {
    return <div>Chargement des détails de l'auteur...</div>;
  }

  // Rendu des détails de l'auteur
  return (
    <div>
      <Navbar />
      <h1>Détails de l'Auteur</h1>
      <p><strong>ID :</strong> {author.ID}</p>
      <p><strong>Nom :</strong> {author.Name}</p>
      <p><strong>Date de Naissance :</strong> {author.Birth_Date}</p>
      <p><strong>Description :</strong> {author.Description}</p>

      <button onClick={() => navigate(-1)}>Retour</button>
    </div>
  );
}

export default AuthorsDetails;