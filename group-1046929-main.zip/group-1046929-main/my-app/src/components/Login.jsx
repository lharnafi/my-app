import { useState } from "react";
import { Link } from "react-router-dom";

function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            console.log("Tentative de connexion...");
            const response = await fetch('http://localhost:4000/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, password }),
                credentials: 'include', // gere les cookies si nécessaire
            });
            console.log("Réponse reçue :", response);

            if (!response.ok) {
                console.log("La réponse contient une erreur.");
                const errorData = await response.json();
                console.log("C'est l'échec : ", errorData);
                throw new Error(errorData.message || "Erreur pendant la connexion");
            }

            setMessage("Connexion réussie !");
        } catch (err) {
            console.log("Une erreur s'est produite :", err);
            setMessage(err.message);
        }
    };

    return (
            <main className="component-container">
                <h2>Login</h2>
                <form className="form" onSubmit={handleLogin}>
                    {/* Email */}
                    <div className="form-group">
                        <label htmlFor="email">Email :</label>
                        <input
                            type="email"
                            value={email}
                            placeholder="email@example.com"
                            onChange={(e) => setEmail(e.target.value)}
                        />
                    </div>
                    {/* Password */}
                    <div className="form-group">
                        <label htmlFor="password">Mot de passe :</label>
                        <input
                            type="password"
                            value={password}
                            placeholder="Mot de passe"
                            onChange={(e) => setPassword(e.target.value)}
                        />
                    </div>
                    {/* Submit Button */}
                    <div className="form-submit">
                        <button className="primary-button" type="submit">Se connecter</button>
                    </div>
                </form>
                {message && <p>{message}</p>}
                <div className="form-secondary-option">
                <p> Pas encore de compte ?</p>
                <Link className="link" to="/signup">
                    <p> Inscrivez-vous ici ! </p>
                </Link>
                </div>
            </main>
    );
}

export default Login;
