 import { useState } from "react";
 import { Link } from "react-router-dom";

function GetBooks(){
    const [books, setBooks] = useState([]);


  const fetchData = async () => {
    console.log("Fetch la liste des livres");
    try {
      const response = await fetch("http://localhost:4000/api/books", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: 'include',
      });
  
      if (response.ok) {
        const data = await response.json();
        setBooks(data || []); 
        console.log("Réponse reçue:", data.details); 
        
        
      } else {
        console.error("Erreur lors du fetch des livres", response.status);
      }
    } catch (err) {
      console.log("Une erreur s'est produite :", err);
    }
  };
  
  console.log(books);
  return (
    <div>
      <h1>Library</h1>
      <div>
        <h2>Liste des données</h2>
        <ul>
          {Array.isArray(books.details) && books.details.map((item) => (
            <li key={item.ID}>
              {item.ID} {item.Title} 
              <Link to={`/books/${item.ID}`}>
                  <button>Afficher le livre</button>
                </Link>
            </li>
          ))}
        </ul>
        <button onClick={fetchData}>Afficher les livres</button>
        
      </div>
    </div>
  );
}

export default GetBooks;
