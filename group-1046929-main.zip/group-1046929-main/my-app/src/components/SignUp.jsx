import { useState } from "react";
import { Link } from "react-router-dom";


function SignUp() {
    const [firstName, setFirstName]= useState('');
    const [lastName, setLastName]= useState('');
    const [email, setEmail]= useState('');
    const [password, setPassword]= useState('');
    const [message, setMessage] = useState('')
    
    const HandleSignUp = async (e)=>{
        e.preventDefault();
        try{
            console.log("tentative d'inscription");
            const response = await fetch('http://localhost:4000/api/auth/signup',{
                method : 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({firstName, lastName, email, password}),

                credentials: 'include',
            });
            console.log("reponse reçu:", response);

            if (!response.ok) {
                console.log("la reponse contient une erreur")
                const errorData = await response.json();
                console.log("c'est le echoueyyy",errorData);
                throw new Error(errorData.message || "erreur pendent la connexion" )
            }


            setMessage("insccription reussie c'est le fonctionneyyyyyyy");
         } catch (err){
                console.log("Une erreur s'est produite :", err); // Log des erreurs capturées dans le bloc catch
                setMessage(err.message);
            }
        };
    
        return (

                <main className="component-container">
                    <h2>Sign Up</h2>
                    <form className="form" onSubmit={HandleSignUp}>
                        {/* Nom */}
                        <div className="form-group">
                            <label htmlFor="firstName">Nom :</label>
                            <input 
                                type="text"
                                value={firstName}
                                placeholder="Votre nom"
                                onChange={(e)=> setFirstName(e.target.value)}
                            />
                        </div>
                        {/* Prénom */}
                        <div className="form-group">
                            <label htmlFor="lastName">Prénom :</label>
                            <input 
                                type="text"
                                value={lastName}
                                placeholder="Votre Prénom"
                                onChange={(e)=> setLastName(e.target.value)}
                            />
                        </div>
                        {/* Email */}
                        <div className="form-group">
                            <label htmlFor="email">Email :</label>
                            <input 
                                type="email"  
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                            />
                        </div>
                        {/* Password */}
                        <div className="form-group">
                            <label htmlFor="password">Mot de passe :</label>
                            <input
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                            />
                        </div>
                        {/* Submit Button */}
                        <div className="form-submit">
                            <button className="primary-button" type="submit">S'inscrire</button>
                        </div>
                    </form>
                    {message && <p>{message}</p>}
                    <div className="form-secondary-option">
                    <p> Deja un compte ?</p>
                    <Link className="link" to="/login">
                        <p> Connecter vous ! </p>
                    </Link>
                    </div>
                </main>

        );
    }
    
    export default SignUp;
