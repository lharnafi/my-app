import { useState } from "react";
import { useNavigate } from "react-router-dom";
import '../css/cart.css'

function GetCart() {
  const [carts, setCarts] = useState([]); 
  const [error, setError] = useState(null); 
  const [successMessage, setSuccessMessage] = useState("");
  const navigate = useNavigate();
  
  const fetchDataCart = async () => {
    console.log("Récupération du panier...");
    try {
      const response = await fetch("http://localhost:4000/api/purchase/cart", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include", 
      });

      const booksFromDb = await fetch("http://localhost:4000/api/books", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
      })

      if (response.ok && booksFromDb.ok) {
        const data = await response.json();
        const lib = await booksFromDb.json();

        const cartArr = data.cart 
   

       const filteredArr =  cartArr.filter((e) => e.BookId == 4)
       console.log("TEST FILTRE", filteredArr)

       const details = lib.details

       console.log(details)
       const detailedCart = details.filter(book => cartArr.some(item => item.BookId === book.ID)).map(book => {
        const quantity = cartArr.find(item => item.BookId === book.ID).Quantity
        return {...book, Quantity: quantity}
       })
        setCarts(detailedCart || []); 
        
      } else {
        setError("Erreur lors de la récupération du panier");
        console.error("Erreur HTTP:", response.status);
      }
    } catch (err) {
      setError("Une erreur s'est produite lors de la récupération du panier");
      console.log("Erreur:", err);
    }
  };


  const handleDelete = async (bookId) => {
    console.log(`Suppression de l'article avec l'ID ${bookId}...`);
    try {
      const response = await fetch("http://localhost:4000/api/purchase/cart", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({ bookId }),
      });

      if (response.ok) {
        console.log("Article supprimé avec succès");
        setSuccessMessage("L'article a bien été supprimé."); // Afficher le message de succès
        setError(null); // Réinitialiser les erreurs
        fetchDataCart(); // Recharger le panier

      } else {
        setError("Erreur lors de la suppression de l'article");
        console.error("Erreur HTTP:", response.status);
      }
    } catch (err) {
      setError("Une erreur s'est produite lors de la suppression de l'article");
      console.log("Erreur:", err);
    }
  };


  // Finaliser l'achat
  const finalizePurchase = async () => {
    if (carts.length === 0) {
      setError("Le panier est vide !");
      return;
    }

    try {
      const response = await fetch("http://localhost:4000/api/purchase/cart/finalize", {
        method: "POST", 
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include", 
      });

      if (response.ok) {
        const data = await response.json();
        setSuccessMessage(`Achat finalisé avec succès. Montant total : ${data.totalAmount} €`);
        setError(null);
        fetchDataCart(); // Rafraîchir le panier
        navigate("/thank-you"); //page merci
      } else {
        setError("Erreur lors de la finalisation de l'achat");
        setSuccessMessage("");
      }
    } catch (err) {
      setError("Une erreur s'est produite lors de la finalisation de l'achat");
      setSuccessMessage("");
      console.error(err);
    }
  };

  for (var key in carts) {
    
    if (!carts.hasOwnProperty(key)) continue;

    var obj = carts[key];
    for (var prop in obj) {
       
        if (!obj.hasOwnProperty(prop)) continue;       
    }
  }

  return (
    <div className="component-container">
      <h1 className="main-title">Mon Panier</h1>

      {error && <p style={{ color: "red" }}>{error}</p>}
      {successMessage && <p style={{ color: "green" }}>{successMessage}</p>} 
    
      <div className="cart-table">
        {
         carts && carts.length > 0  && 
          <div className="cart-header cart-row">
          <div className="cart-col">Titre</div>
          <div className="cart-col">ID</div>
          <div className="cart-col">Quantité</div>
          <div className="cart-col">Suprimé</div>
        </div>
        }
        {Array.isArray(carts) &&
          carts.map((item, index) => (
            <div className="cart-row" key={index}>
              <div className="cart-col">{item.Title}</div>
              <div className="cart-col">{item.ID} </div>
              <div className="cart-col">{item.Quantity}</div>
              <button
                onClick={() => {
                  if (window.confirm("Voulez-vous vraiment supprimer cet article ?")) {
                    handleDelete(item.BookId);
                  }
                }}> 
                Supprimer
              </button>
            </div>
          ))}
      </div>
      <div className="cart-btns">
        {
          carts && carts.length > 0 && 
          <button className="secondary-button" onClick={finalizePurchase}>Finaliser l'achat</button>
        }
        {
          !carts || carts.length == 0 &&
          <button className="primary-button" onClick={fetchDataCart}>Voir le panier</button>
        }
      </div>
    </div>
  );
}

export default GetCart;