import React from "react";
import Navbar from "../components/Navbar";
import BookDetails from "../components/BooksDetails";

export default function Books() {
  return (
    <div>
      <Navbar />
      <h1>Books Page</h1>
      <BookDetails />
    </div>
  );
}
