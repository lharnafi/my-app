import React from "react";
import Navbar from "../components/Navbar";
import AuthorDetails from "../components/AuthorsDetails";

export default function Authors() {
  return (
    <div>
      <Navbar />
      <h1>Books Page</h1>
      <AuthorDetails />
    </div>
  );
}