// import React from "react";
// import Navbar from "../components/Navbar";
// import History from "../components/History";

// export default function Books() {
//   return (
//     <div>
//       <Navbar />
//       <h1>Historique d'achat</h1>
//       <History />
//     </div>
//   );
// }
