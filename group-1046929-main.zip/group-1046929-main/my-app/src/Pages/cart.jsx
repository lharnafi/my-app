import React from "react";
import Navbar from "../components/Navbar";
import GetCart from "../components/GetCart";


export default function Cart() {
  return (
    <div>
      <Navbar />
      <h1 className="main-page-title">Cart</h1>
      <GetCart/>
      
    </div>
  );
}
