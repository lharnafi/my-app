import React from "react";
import Navbar from "../components/Navbar";
import GetAuteur from "../components/GetAuteur";

export default function Authors() {
  return (
    <div>
      <Navbar />
      <h1>Authors Page</h1>
      <GetAuteur />
    
    </div>
  );
}
