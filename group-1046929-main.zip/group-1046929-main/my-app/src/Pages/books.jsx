import React from "react";
import Navbar from "../components/Navbar";
import GetBooks from "../components/GetBooks";

export default function Books() {
  return (
    <div>
      <Navbar />
      <h1>Books Page</h1>
      <GetBooks />
    </div>
  );
}
