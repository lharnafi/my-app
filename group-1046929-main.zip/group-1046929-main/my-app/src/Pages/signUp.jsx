import React from "react";
import Navbar from "../components/Navbar";
import SignUp from "../components/SignUp";


export default function Users() {
  return (
    <div>
      <Navbar />
      <h1>Users Page</h1>
      <SignUp />
    </div>
  );
}
