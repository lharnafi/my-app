import React from "react";
import Navbar from "../components/Navbar";
import Login from "../components/Login";

export default function LoginUser() {
  return (
    <div>
      <Navbar />
      <h1>Login Page</h1>
      <Login />
    </div>
  );
}
