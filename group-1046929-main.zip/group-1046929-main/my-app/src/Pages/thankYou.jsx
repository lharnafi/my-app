import React from "react";
import Navbar from "../components/Navbar";

export default function Thankyou() {
  return (
    <div>
      <Navbar />
      <h1>Thank you!</h1>
      <p>Thank you for buying from us, we hope to see you soon!</p>
    </div>
  );
}
