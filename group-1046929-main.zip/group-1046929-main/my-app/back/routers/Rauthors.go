package routers 

import (
	"MYAPI/controllers"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func AuthorsRouters(router *gin.Engine, db *gorm.DB) *gin.Engine {
	authorsRepository := controllers.AuthorsRepository{
		Db: db, 
	}

	authorsGroup := router.Group("/authors")

	{
		authorsGroup.GET("", authorsRepository.GetAuthors) // renvoie la liste des auteurs
		authorsGroup.GET(":id", authorsRepository.GetAuthor) // renvoie la liste d'un auteur demandé avec son id 
		authorsGroup.POST("", authorsRepository.PostAuthor) // création / ajout d'un auteur 
		authorsGroup.PUT(":id", authorsRepository.PutAuthor) // modification d'un auteur demandé par id 
		authorsGroup.DELETE(":id", authorsRepository.DeleteAuthor) // suppression d'un auteur 
	}

	return router 
}