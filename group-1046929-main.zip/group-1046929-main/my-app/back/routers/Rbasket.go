package routers 

import (
	"MYAPI/controllers"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func BasketRouters(router *gin.Engine, db *gorm.DB) *gin.Engine {
    basketRepo := controllers.BasketRepository{Db: db}

    basketGroup := router.Group("/basket")
    {
        basketGroup.POST("/", basketRepo.AddToBasket) // Ajout d'un article dans le panier  
        basketGroup.GET("/:user_id", basketRepo.GetBasket) // obtenir l'article ajouter d'un id  
        basketGroup.DELETE("/:id", basketRepo.RemoveFromBasket) // supprimer l'article dans le panier 
        basketGroup.POST("/:id", basketRepo.AddBasket) 
    }

    return router
}

