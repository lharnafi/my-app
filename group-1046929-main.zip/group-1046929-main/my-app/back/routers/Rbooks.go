package routers 

import (
	"MYAPI/controllers"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func BooksRouters(router *gin.Engine, db *gorm.DB) *gin.Engine {
	booksRepo := controllers.BooksRepository{
		Db: db, 
	}

	booksGroup := router.Group("/books")
	{

		booksGroup.GET("/", booksRepo.GetBooks) // renvoie la liste de tous les livres 
		booksGroup.GET("/:id", booksRepo.GetBookByID) // renvoie la liste d'un livre demandé avec son id 
		booksGroup.POST("/", booksRepo.PostBook) // Ajoute un livre 
		booksGroup.PUT(":id", booksRepo.PutBooks) // Modifie les informations d'un livre demandé avec son id 
		booksGroup.DELETE(":id", booksRepo.DeleteBooks)// supprime un livre demandé par son id 
	}

	return router 
} 

