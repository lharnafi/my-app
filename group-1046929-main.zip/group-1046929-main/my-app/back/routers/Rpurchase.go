package routers

import (
	"MYAPI/controllers"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func PurchaseRouters(router *gin.Engine, db *gorm.DB) *gin.Engine {
	purchaseHistoryRepository := controllers.PurchaseHistory{
		Db: db,
	}
	purchaseGroup := router.Group("/purchase")
	{
		purchaseGroup.GET("", purchaseHistoryRepository.PostPurchaseHistory)// affiche l'historique d'achat
		purchaseGroup.GET(":id", purchaseHistoryRepository.GetPurchaseHistoryByID) // affiche l'historique d'achat d'un id
		purchaseGroup.POST("",purchaseHistoryRepository.PostPurchaseHistory) // ajoute un livre dans l'historique d'achat 
		purchaseGroup.DELETE(":id", purchaseHistoryRepository.DeletePurchase) // Supprimer l'historique 
		purchaseGroup.PUT(":id", purchaseHistoryRepository.PutPurchase)
	}
	return router
}
