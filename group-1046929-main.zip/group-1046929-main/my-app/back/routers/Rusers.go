package routers 

import ( 
	"MYAPI/controllers"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
	"MYAPI/middleware"
)

func UserRouters(router *gin.Engine, db *gorm.DB) *gin.Engine {
	usersRepository := controllers.UsersRepository{
		Db : db, 
	}

	usersGroup := router.Group("/users")

	{
		usersGroup.GET("", usersRepository.GetUsers) // renvoie a liste de tous les utilisateurs
		usersGroup.GET("/:id", usersRepository.GetUserByID) // renvoie la liste d'un user avec son id 
		usersGroup.POST("/", usersRepository.PostUsers) // Création d'un nouvel utilisateur 
		usersGroup.PUT("/:id", usersRepository.PutUsers) // modification d'un user avec son id 
		usersGroup.DELETE("/:id", usersRepository.DeleteUsers)// suppression d'un user avec son id 
	
	
		adminGroup := usersGroup.Group("/")
		adminGroup.Use(middleware.AdminOnly(db))

		{
		adminGroup.PUT("/admin/:id", usersRepository.PutUsers)
		adminGroup.DELETE("/admin/:id", usersRepository.DeleteUsers)
		}
	}
	return router
}






