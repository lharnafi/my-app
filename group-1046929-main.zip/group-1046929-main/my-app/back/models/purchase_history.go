package models 

import (
	"gorm.io/gorm"
)


type PurchaseHistory struct {
    Id             int   
    Customers        string 
    BooksPurchased  string 
    PaymentTimestamp string 
	Quantity int
	Price int
}

// Ajoute le livre dans l'historique d'achat 


// Récupère l'historique complet 
func (PH *PurchaseHistory) FindPurchaseHistory(db *gorm.DB) ([]PurchaseHistory, error) { // Ajout d'un historique d'achat
    var purchaseHistory []PurchaseHistory
    err := db.Find(&purchaseHistory).Error
    return purchaseHistory, err
}

// Récupère l'historique d'un utilisateur spécifique par son ID
func (PH *PurchaseHistory) FindPurchaseHistoryByID(db *gorm.DB, id string) ([]PurchaseHistory, error) { // Obtenir l'hsitorique d'achat d'un id 
    var purchaseHistory []PurchaseHistory
    err := db.Where("id = ?", id).Find(&purchaseHistory).Error
    return purchaseHistory, err
}

// Supprime l'historique d'achat d'un utilisateur en tant qu'admin

func (PH *PurchaseHistory) DeletePurchaseHistory(db *gorm.DB, id string) error {
   
    if err := db.Where("id = ?", id).Delete(&PurchaseHistory{}).Error; err != nil {
        return err
    }
    return nil
}

