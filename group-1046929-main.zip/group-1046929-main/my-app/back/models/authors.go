package models

import(
    "gorm.io/gorm"
)

type Authors struct { 
    Id          int   
    Name        string        
    BirthDate   string   
    Description string 
}

// Ajouter un nouvel auteur
func (a *Authors) SaveOrUpdateAuthor(db *gorm.DB) error { 
    if err := db.Save(a).Error; err != nil {
        return err
    }
    return nil
}

// Récupère tous les auteurs
func FindAuthors(db *gorm.DB) ([]Authors, error) {
    var authors []Authors
    if err := db.Find(&authors).Error; err != nil {
        return nil, err
    }
    return authors, nil
}

// Récupère un auteur par ID
func (a *Authors) FindAuthor(db *gorm.DB, id string) (*Authors, error) {
    var author Authors
    if err := db.First(&author, id).Error; err != nil {
        return nil, err
    }
    return &author, nil
}

// Supprime un auteur par ID
func (a *Authors) RemoveAuthor(db *gorm.DB, id string) error {
    if err := db.Delete(&Authors{}, id).Error; err != nil {
        return err
    }
    return nil
}

// Modifier l'auteur possédant l'id donné 
func (a *Authors) SaveOrUpdateAuthors(db *gorm.DB) error {
    return db.Model(&a).Save(a).Error
}