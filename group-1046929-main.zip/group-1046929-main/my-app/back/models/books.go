package models 

import (
	"gorm.io/gorm"

)


type Books struct { 
    Id int 
    Title string 
    Authors string
    Publication_date string 
    Resume string 
    Stock int 
    Price int 
}
func FindBooks(db *gorm.DB) ([]Books, error) { // Renvoie la liste des livres
    var books []Books
    if err := db.Find(&books).Error; err != nil {
        return nil, err
    }
    return books, nil
}

func (b *Books) FindBook(db *gorm.DB, id string) (*Books, error) { // Renvois les informations du livre possédant l'id donné 
    var book Books
    if err := db.First(&book, id).Error; err != nil {
        return nil, err
    }
    return &book, nil
}

func (b *Books) SaveOrUpdateBook(db *gorm.DB) error { // Ajouter un nouvel livre 
    if err := db.Save(b).Error; err != nil {
        return err
    }
    return nil
}

//  Modifier le livre possédant l'id donné
func (b *Books) SaveOrUpdateBooks(db *gorm.DB) error {
    return db.Model(&b).Save(b).Error
}

// Supprimer le livre sélectionné 
func (b *Books) RemoveBook(db *gorm.DB, id string) error {
    return db.Delete(&b,id).Error //modification ici singe
}