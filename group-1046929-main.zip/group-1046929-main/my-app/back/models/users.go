package models 

import (
	"gorm.io/gorm"
)

type Users struct {
    Id      int    
    Name     string 
    FirstName string 
    Email    string 
    Password string 
    IsAdmin  bool   
}

// Renvoie la liste des utiisateurs 
func (u *Users) FindUsers(db *gorm.DB) (*[]Users, error) {
    var users []Users
    err := db.Find(&users).Error
    return &users, err
}

// Renvois les informations de l'utilisateur possédant l'id donné
func (u *Users) FindUser(db *gorm.DB, id string) (*Users, error) {
    var user Users
    err := db.Take(&user, id).Error
    return &user, err
}

// Créer un nouvel utlisateur 
func (u *Users) SaveOrUpdateUser(db *gorm.DB) error { 
    if err := db.Save(u).Error; err != nil {
        return err
    }
    return nil
}

// Modifie l'utilisateur possédant l'id donné
func (u *Users) SaveOrUpdateUserid(db *gorm.DB) error {
    return db.Model(&u).Save(u).Error
}

// Supprime l'utilisateur sélectionné avec l'id 
func (u *Users) RemoveUser(db *gorm.DB, id string) error {
    if err := db.Delete(&Users{}, id).Error; err != nil {
        return err
    }
    return nil
}


