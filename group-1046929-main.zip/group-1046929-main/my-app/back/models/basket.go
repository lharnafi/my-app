package models

type Basket struct {
    Id         int   
    User_Id     int   
    Book_Id  int 
    Quantity   int     
    Total_Price int
}



