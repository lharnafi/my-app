package database

import (
    "fmt"
    "log"
    "gorm.io/driver/mysql"
    "gorm.io/gorm"
)

var DB *gorm.DB

func Init() {
    var err error

    // Configuration de la chaîne de connexion
    dsn := "poli:poli@tcp(localhost:3306)/library?charset=utf8mb4&parseTime=True&loc=Local"

    // Connexion à la base de données avec GORM
    DB, err = gorm.Open(mysql.Open(dsn), &gorm.Config{})
    if err != nil {
        log.Fatalf("Erreur lors de la connexion à la base de données : %v", err)
    }

    // Teste la connexion
    sqlDB, err := DB.DB() // Récupère l'instance de base de données native
    if err != nil {
        log.Fatalf("Impossible de récupérer l'instance native : %v", err)
    }

    if err = sqlDB.Ping(); err != nil {
        log.Fatalf("Impossible de ping la base de données : %v", err)
    }

    fmt.Println("Connexion à la base de données réussie avec GORM !")
}

func GetDB() *gorm.DB {
    if  DB == nil {
        log.Fatal("Database is not initialized!")
    }
    return DB
}