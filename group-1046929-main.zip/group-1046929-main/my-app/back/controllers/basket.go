package controllers

import (
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "MYAPI/models"
	
)

type BasketRepository struct {
    Db *gorm.DB
}


func (repository *BasketRepository) AddToBasket(c *gin.Context) { // Ajout dans le panier 
    var basket models.Basket

    if err := c.ShouldBindJSON(&basket); err != nil {
        c.JSON(422, gin.H{"erreur": err.Error()})
        return
    }

     
    var book models.Books
    if err := repository.Db.First(&book, basket.Book_Id).Error; err != nil {
        c.JSON(404, gin.H{"erreur": "Livre introuvable"})
        return
    }
    basket.Total_Price = int(basket.Quantity) * book.Price

    if err := repository.Db.Create(&basket).Error; err != nil {
        c.JSON(500, gin.H{"erreur": "Echec de l'ajout au panier"})
        return
    }

    c.JSON(201, gin.H{"succès": basket})
}


func (repository *BasketRepository) GetBasket(c *gin.Context) { // Obtenir l'article ajouter dans le panier 
    userID := c.Param("user_id")
    var basket []models.Basket

    if err := repository.Db.Where("user_id = ?", userID).Find(&basket).Error; err != nil {
        c.JSON(500, gin.H{"erreur": "Echec"})
        return
    }

    c.JSON(200, gin.H{"basket": basket})
}


func (repository *BasketRepository) RemoveFromBasket(c *gin.Context) { // Supprimer du panier 
    id := c.Param("id")
    if err := repository.Db.Delete(&models.Basket{}, id).Error; err != nil {
        c.JSON(500, gin.H{"erreur": "Echec: le produit n'a pas pu être supprimé"})
        return
    }

    c.JSON(200, gin.H{"succès": "Produit supprimé avec succés"})
}

func (repository *BasketRepository) AddBasket(c *gin.Context) {
    var basket models.Basket

    if err := c.ShouldBindJSON(&basket); err != nil {
        c.JSON(422, gin.H{"erreur": err.Error()})
        return
    }

    // Vérifier que le livre existe
    var book models.Books
    if err := repository.Db.First(&book, basket.Book_Id).Error; err != nil {
        c.JSON(404, gin.H{"erreur": "Livre introuvable"})
        return
    }

    // Vérifier que l'utilisateur existe
    var user models.Users
    if err := repository.Db.First(&user, basket.User_Id).Error; err != nil {
        c.JSON(404, gin.H{"erreur": "Utilisateur introuvable"})
        return
    }

    // Calculer le prix total
    basket.Total_Price = int(basket.Quantity) * book.Price

    // Sauvegarder le panier
    if err := repository.Db.Create(&basket).Error; err != nil {
        c.JSON(500, gin.H{"erreur": "Echec de l'ajout au panier"})
        return
    }

    c.JSON(201, gin.H{"succès": basket})
}


