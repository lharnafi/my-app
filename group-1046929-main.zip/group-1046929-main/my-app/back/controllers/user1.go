package controllers

import (
    "os"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "MYAPI/models"
    "golang.org/x/crypto/bcrypt"
    "github.com/golang-jwt/jwt/v5"
)

type UsersRepository struct {
    Db *gorm.DB
}

func Error500(c *gin.Context) {
    c.JSON(500, gin.H{"error": "Something went wrong"})
}

func Error404(c *gin.Context) {
    c.JSON(404, gin.H{"error": "User not found"})
}

// Renvoie la liste des utilisateurs
func (repository *UsersRepository) GetUsers(c *gin.Context) {
    var users []models.Users //

   
    if err := repository.Db.Find(&users).Error; err != nil {
        Error500(c)
        return
    }

    c.JSON(200, users) 
}


//AJOUT
//generer le token

func GenerateToken(userID string, isAdmin bool) (string, error) {
    secret := os.Getenv("JWT_SECRET")
    claims := jwt.MapClaims{
        "user_id": userID,
        "is_admin": isAdmin,
    }
    token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
    return token.SignedString([]byte(secret))
  }

// Obtenir un utilisateur avec son ID
func (repository *UsersRepository) GetUserByID(c *gin.Context) {
    id := c.Params.ByName("id") // Récupérer l'ID depuis l'URL
    var user models.Users       // Un seul utilisateur

    // Trouver l'utilisateur avec cet ID
    if err := repository.Db.First(&user, "id = ?", id).Error; err != nil {
        Error404(c) // Si l'utilisateur n'est pas trouvé
        return
    }

    c.JSON(200, user) // Retourner l'utilisateur
}

//creer un user (admin if first)
func (repository *UsersRepository) PostUsers(c *gin.Context) {
    var user models.Users // Un nouvel utilisateur

    
    if err := c.ShouldBindJSON(&user); err != nil {
        c.JSON(422, gin.H{"error": err.Error()})
        return
    }

    // Hashing du mot de passe
    hashedPassword, err := HashPassword(user.Password)
    if err != nil {
        c.JSON(500, gin.H{"error": "Failed to hash password"})
        return
    }
    user.Password = hashedPassword // Remplacer le mot de passe en clair par le mot de passe haché

    // Vérifier si la base de données est vide
    var userCount int64
    if err := repository.Db.Model(&models.Users{}).Count(&userCount).Error; err != nil {
        c.JSON(500, gin.H{"error": "Failed to check user count"})
        return
    }

    // Si aucun utilisateur n'existe, attribuer le rôle admin
    if userCount == 0 {
        user.IsAdmin = true
    }

    // Sauvegarder l'utilisateur dans la base de données
    if err := repository.Db.Create(&user).Error; err != nil {
        Error500(c)
        return
    }

    c.JSON(201, gin.H{"success": user})
}


// Modifier un utilisateur avec l'ID
func (repository *UsersRepository) PutUsers(c *gin.Context) {
    id := c.Params.ByName("id") // Récupérer l'ID depuis l'URL
    var user models.Users       // Un seul utilisateur

    // Trouver l'utilisateur avec cet ID
    if err := repository.Db.First(&user, "id = ?", id).Error; err != nil {
        Error404(c)
        return
    }

    // Mettre à jour les informations de l'utilisateur avec les données envoyées
    if err := c.ShouldBindJSON(&user); err != nil {
        c.JSON(422, gin.H{"error": err.Error()})
        return
    }

    // Sauvegarder les modifications dans la base de données
    if err := repository.Db.Save(&user).Error; err != nil {
        Error500(c)
        return
    }

    c.JSON(200, gin.H{"success": user})
}

// Supprimer un utilisateur
func (repository *UsersRepository) DeleteUsers(c *gin.Context) {
    id := c.Params.ByName("id") // Récupérer l'ID depuis l'URL
    var user models.Users       // Un seul utilisateur

    // Trouver l'utilisateur avec cet ID
    if err := repository.Db.First(&user, "id = ?", id).Error; err != nil {
        Error404(c)
        return
    }

    // Supprimer l'utilisateur de la base de données
    if err := repository.Db.Delete(&user).Error; err != nil {
        Error500(c)
        return
    }

    c.JSON(200, gin.H{"success": "User " + id + " deleted"})
}



//Hashing password 
func HashPassword(password string) (string, error) {
    bytes, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
    return string(bytes), err
}


func CheckPasswordHash(password, hash string) bool {
    err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password))
    return err == nil
}
