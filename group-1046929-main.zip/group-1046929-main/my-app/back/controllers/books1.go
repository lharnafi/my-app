package controllers

import (
	"MYAPI/models"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type BooksRepository struct {
    Db *gorm.DB
}


func Error5(c *gin.Context) {
    c.JSON(500, gin.H{"error": "Something went wrong"})
}
func Error4(c *gin.Context) {
    c.JSON(404, gin.H{"error": "Book not found"})
}


// Renvois la liste des livres
func (repository *BooksRepository) GetBooks(c *gin.Context) {
    var books []models.Books 
    if err := repository.Db.Find(&books).Error; err != nil {
        error500(c)
        return
    }
    c.JSON(200, books)
}


// Renvois les informations du livre possédant l'id donné
func (repository *BooksRepository) GetBookByID(c *gin.Context) {
    id := c.Param("id")
    var book models.Books

    if err := repository.Db.First(&book, "id = ?", id).Error; err != nil {
        if err == gorm.ErrRecordNotFound {
            error404(c)
        } else {
            error500(c)
        }
        return
    }

    c.JSON(200, book)
}

// Ajoute un nouveau livre
func (repository *BooksRepository) PostBook(c *gin.Context) {
    var book models.Books

    if err := c.ShouldBindJSON(&book); err != nil {
        c.JSON(422, gin.H{"error": err.Error()})
        return
    }

    if err := book.SaveOrUpdateBook(repository.Db); err != nil {
        error500(c)
        return
    }

    c.JSON(201, gin.H{"Le livre a bien été ajouté": book})
}


// Modifier le livre possédant l'id donné
func (repository *BooksRepository) PutBooks(c *gin.Context){
    id := c.Params.ByName("id")
    var bookModel models.Books
    book, err := bookModel.FindBook(repository.Db, id)

    if book.Id == 0 {
        error404(c)
        return
    }

    if err := c.ShouldBindJSON(&book); err != nil {
        c.JSON(422, gin.H{"error": err.Error()})
        return
    }

    if err != nil {
        error500(c)
        return
    }

    if err = bookModel.SaveOrUpdateBook(repository.Db); err != nil {
        error500(c)
        return
    }

    c.JSON(200, gin.H{"Le livre a été ajouté avec succès": book})
}

// Supprimer le livre sélectionné
func (repository *BooksRepository) DeleteBooks (c *gin.Context){
    id:= c.Param("id")
    var bookModel models.Books
    _, err := bookModel.FindBook(repository.Db, id)

    if err != nil {
        error404(c)
        return
    }

    if err := bookModel.RemoveBook(repository.Db, id); err == nil {
        error500(c)
        return
    }

    c.JSON(200, gin.H{"Le livre ": " #" + id + " à été supprimé"})
}