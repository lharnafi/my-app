package controllers

import (
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "net/http"
    "MYAPI/models"
)

type PurchaseHistory struct {
    Db *gorm.DB
}

func error5(c *gin.Context) {
    c.JSON(500, gin.H{"error": "Something went wrong"})
}

func error4(c *gin.Context) {
    c.JSON(404, gin.H{"error": "PurchaseHistory not found"})
}

// Affiche l'historique de l'utilisateur courant
func (repository *PurchaseHistory) GetUserPurchaseHistory(c *gin.Context) {
    var purchasehistoryModel models.PurchaseHistory
    purchaseHistory, err := purchasehistoryModel.FindPurchaseHistory(repository.Db)

    if err != nil {
        error5(c)
        return
    }
    c.JSON(http.StatusOK, purchaseHistory)
}

// Affiche l'historique d'un utilisateur donné
func (repository *PurchaseHistory) GetPurchaseHistoryByID(c *gin.Context) {
    id := c.Param("id")
    var purchasehistoryModel models.PurchaseHistory
    purchaseHistory, err := purchasehistoryModel.FindPurchaseHistoryByID(repository.Db, id)

    if err != nil {
        error5(c)
        return
    }

    if len(purchaseHistory) == 0 {
        error4(c)
        return
    }

    c.JSON(http.StatusOK, purchaseHistory)
}

// Supprimer l'historique d'achat (en tant qu'admin)
func (repository *PurchaseHistory) DeletePurchase(c *gin.Context) {
    id := c.Param("id") // Récupérer l'ID depuis les paramètres de la requête
    var purchaseHistory models.PurchaseHistory

    // Chercher l'historique d'achat correspondant
    if err := repository.Db.First(&purchaseHistory, id).Error; err != nil {
        if err == gorm.ErrRecordNotFound {
            c.JSON(404, gin.H{"error": "Purchase history not found"})
        } else {
            c.JSON(500, gin.H{"error": "Something went wrong"})
        }
        return
    }

    // Supprimer l'entrée dans la base de données
    if err := repository.Db.Delete(&purchaseHistory).Error; err != nil {
        c.JSON(500, gin.H{"error": "Failed to delete purchase history"})
        return
    }

    c.JSON(200, gin.H{"success": "Purchase history deleted successfully"})
}


// Mise à jour de l'historique d'achat 
func (repository *PurchaseHistory) PutPurchase(c *gin.Context) {
    id := c.Param("id") // Récupère l'ID depuis les paramètres de la requête
    var purchaseHistory models.PurchaseHistory

    // Cherche l'achat par ID
    if err := repository.Db.First(&purchaseHistory, id).Error; err != nil {
        if err == gorm.ErrRecordNotFound {
            c.JSON(404, gin.H{"error": "Purchase not found"})
        } else {
            c.JSON(500, gin.H{"error": "Something went wrong"})
        }
        return
    }

   
    if err := c.ShouldBindJSON(&purchaseHistory); err != nil {
        c.JSON(422, gin.H{"error": err.Error()})
        return
    }

    // Sauvegarde les modifications
    if err := repository.Db.Save(&purchaseHistory).Error; err != nil {
        c.JSON(500, gin.H{"error": "Failed to update purchase"})
        return
    }

    c.JSON(200, gin.H{"success": purchaseHistory})
}

//
func (repository *PurchaseHistory) PostPurchaseHistory(c *gin.Context) { // Ajout d'un livre dans mon historique d'achat 
    var purchaseHistory models.PurchaseHistory // Un nouvel utilisateur

    
    if err := c.ShouldBindJSON(&purchaseHistory); err != nil {
        c.JSON(422, gin.H{"error": err.Error()}) 
    }

    // Sauvegarder l'utilisateur dans la base de données
    if err := repository.Db.Create(&purchaseHistory).Error; err != nil {
        Error500(c)
        return
    }

    c.JSON(201, gin.H{"success": purchaseHistory})
}


