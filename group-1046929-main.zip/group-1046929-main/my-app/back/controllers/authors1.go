package controllers

import (
	"MYAPI/models"
	"fmt"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type AuthorsRepository struct { 
    Db *gorm.DB
}

func error500(c *gin.Context) {
    c.JSON(500, gin.H{"error": "Something went wrong"})
}

func error404(c *gin.Context) {
    c.JSON(404, gin.H{"error": "Author not found"})
}

// Ajouter un auteur
func (repository *AuthorsRepository) PostAuthor(c *gin.Context) {
    var authorModel models.Authors

    if err := c.ShouldBindJSON(&authorModel); err != nil {
        c.JSON(422, gin.H{"error": err.Error()})
        return
    }

    if err := authorModel.SaveOrUpdateAuthor(repository.Db); err != nil {
        error500(c)
        return
    }
    c.JSON(201, gin.H{"success": authorModel})
}

// Renvoie la liste des auteurs
func (repository *AuthorsRepository) GetAuthors(c *gin.Context) {
    authors, err := models.FindAuthors(repository.Db)
    if err != nil {
        error500(c)
        return
    }
    c.JSON(200, authors)
}

// Renvoie les informations de l'auteur possédant l'id donné
func (repository *AuthorsRepository) GetAuthor(c *gin.Context) {
    id := c.Params.ByName("id")
    var authorModel models.Authors
    author, err := authorModel.FindAuthor(repository.Db, id)

    if err != nil {
        error404(c)
        return
    }

    c.JSON(200, author)
}

// Modifier l'auteur possédant l'id donné
func (repository *AuthorsRepository) PutAuthor(c *gin.Context) {
    id := c.Params.ByName("id")
    var authorModel models.Authors
    author, err := authorModel.FindAuthor(repository.Db, id)

    if err != nil {
        fmt.Println(author)
        error404(c)
        return
    }

    if err := c.ShouldBindJSON(&author); err != nil {
        c.JSON(422, gin.H{"error": err.Error()})
        return
    }

    if err = author.SaveOrUpdateAuthors(repository.Db); err != nil {
        fmt.Println("Erreur : ", author, err)
        error500(c)
        return
    }

    c.JSON(200, gin.H{"success": author})
}

// Supprimer l'auteur sélectionné
func (repository *AuthorsRepository) DeleteAuthor(c *gin.Context) {
    id := c.Params.ByName("id")
    var authorModel models.Authors
    _, err := authorModel.FindAuthor(repository.Db, id)

    if err != nil {
        error404(c)
        return
    }

    if err := authorModel.RemoveAuthor(repository.Db, id); err != nil {
        error500(c)
        return
    }

    c.JSON(200, gin.H{"success": "Author #" + id + " deleted"})
}