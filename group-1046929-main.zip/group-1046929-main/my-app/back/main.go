package main

import (
    "MYAPI/database"
    "MYAPI/routers"
    "github.com/gin-gonic/gin"
    "github.com/gin-contrib/cors"
    "gorm.io/gorm"    
)

func main() {
    database.Init()
    db := database.GetDB()

    // Initialisation du routeur Gin
    router := gin.Default()
    router.Use(cors.New(cors.Config{
        AllowOrigins:     []string{"https://foo.com"},
        AllowMethods:     []string{"PUT", "PATCH"},
        AllowHeaders:     []string{"Origin"},
        ExposeHeaders:    []string{"Content-Length"},
        AllowCredentials: true,
        AllowOriginFunc: func(origin string) bool {
          return origin == "https://github.com"
        },
        MaxAge: 24,
      }))
    

    // Configuration des routes
    routers.AuthorsRouters(router, db)
    routers.UserRouters(router, db)
    routers.BooksRouters(router, db)
    routers.PurchaseRouters(router, db)
    routers.BasketRouters(router, db)
    


    // Lancement du serveur
    router.Run("localhost:3001")
    
}

var DB *gorm.DB

