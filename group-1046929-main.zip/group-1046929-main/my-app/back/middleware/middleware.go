package middleware

import (
    "github.com/dgrijalva/jwt-go"
    "github.com/gin-gonic/gin"
    "net/http"
    "MYAPI/models"
    "gorm.io/gorm"
    "os"
)

func AdminOnly(db *gorm.DB) gin.HandlerFunc {
    return func(c *gin.Context) {
        // Récupérer le token de l'en-tête Authorization
        tokenString := c.GetHeader("Authorization")
        if tokenString == "" {
            c.JSON(http.StatusUnauthorized, gin.H{"error": "Token is required"})
            c.Abort()
            return
        }

        // Vérifier et décoder le token
        token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
            // Vérifier que la méthode de signature est HMAC
            if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
                return nil, jwt.ErrSignatureInvalid
            }
            return []byte(os.Getenv("JWT_SECRET")), nil // Secret pour signer/valider le token
        })

        if err != nil || !token.Valid {
            c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid token"})
            c.Abort()
            return
        }

        // Extraire les claims (données du token)
        claims, ok := token.Claims.(jwt.MapClaims)
        if !ok || !token.Valid {
            c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid token claims"})
            c.Abort()
            return
        }

        // Récupérer l'ID utilisateur depuis les claims
        userID, ok := claims["user_id"].(string)
        if !ok {
            c.JSON(http.StatusUnauthorized, gin.H{"error": "User ID not found in token"})
            c.Abort()
            return
        }

        // Vérifier si l'utilisateur existe et s'il est admin
        var user models.Users
        if err := db.First(&user, userID).Error; err != nil {
            c.JSON(http.StatusUnauthorized, gin.H{"error": "User not found"})
            c.Abort()
            return
        }

        if !user.IsAdmin {
            c.JSON(http.StatusForbidden, gin.H{"error": "Access denied: Admins only"})
            c.Abort()
            return
        }

        // L'utilisateur est admin, continuer vers la route suivante
        c.Next()
    }
}

// package middleware

// import (
//     "github.com/gin-gonic/gin"
//     "net/http"
//     "MYAPI/models"
//     "gorm.io/gorm"
// )

// func AdminOnly(db *gorm.DB) gin.HandlerFunc {
//     return func(c *gin.Context) {
//         userID := c.GetHeader("user_id") 
//         if userID == "" {
//             c.JSON(http.StatusUnauthorized, gin.H{"error": "User ID is required"})
//             c.Abort()
//             return
//         }

//         var user models.Users
//         if err := db.First(&user, userID).Error; err != nil {
//             c.JSON(http.StatusUnauthorized, gin.H{"error": "User not found"})
//             c.Abort()
//             return
//         }

//         if !user.IsAdmin {
//             c.JSON(http.StatusForbidden, gin.H{"error": "Access denied: Admins only"})
//             c.Abort()
//             return
//         }

//         c.Next() // L'utilisateur est admin, continuer vers la route suivante
//     }
// }
